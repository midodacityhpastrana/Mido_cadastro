<?php 
  session_start();
  if(isset($_SESSION['unique_id'])){
    header("location: users.php");
  }
?>

<?php include_once "header.php"; ?>
<meta charset="utf-8" />
<link rel="stylesheet" href="style.css" type="text/css" media="all" />
<body>
  <div class="wrapper">
    <section class="form signup">
      <header>Cadastrar-se|ADM |Mido</header>
      <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>
        <div class="name-details">
          <div class="field input">
            <label>Primeiro Nome</label>
            <input type="text" name="fname" placeholder="primeiro nome" required>
          </div>
          <div class="field input">
            <label>sobre Nome</label>
            <input type="text" name="lname" placeholder="Primeiro" required>
          </div>
        </div>
        <div class="field input">
          <label>Endereço de email</label>
          <input type="text" name="email" placeholder="endereço de e-mail" required>
       </div>
        <div class="field input">
          <label>Password</label>
          <input type="password" name="password" placeholder="criar uma palavra_passe" required>
          <i class="fas fa-eye"></i>
        </div>
        <div class="field image">
          <label>Seleciona uma Imagem</label>
          <input type="file" name="image" accept="image/x-png,image/gif,image/jpeg,image/jpg" required>
        </div>
        <div class="field button">
          <input type="submit" name="submit" value="Cadastrar">
        </div>
      </form>
      <div class="link">Já se inscreveu? <a href="login.php">Conecte-se agora</a></div>
    </section>
  </div>

  <script src="javascript/pass-show-hide.js"></script>
  <script src="javascript/signup.js"></script>
</body>
</html>