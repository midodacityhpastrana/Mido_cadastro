<?php 
  session_start();
  if(isset($_SESSION['unique_id'])){
    header("location: users.php");
  }
?>

<?php include_once "header.php"; ?>
<meta charset="utf-8">
<body>
  <div class="wrapper">
    <section class="form login">
      <header>Login|Mido|Cartms</header>
      <form action="#" method="POST" enctype="multipart/form-data" autocomplete="off">
        <div class="error-text"></div>
        <div class="field input">
          <label>Endereço de e-mail</label>
          <input type="text" name="email" placeholder="Digite seu e-maill" required>
        </div>
        <div class="field input">
          <label>Password</label>
          <input type="password" name="password" placeholder="Coloque sua senha" required>
          <i class="fas fa-eye"></i>
        </div>
        <div class="field button">
          <input type="submit" name="submit" value="Entra">
        </div>
      </form>
      <div class="link">Ainda não se inscreveu? <a href="index.php">Inscreva-se agora</a></div>
    </section>
  </div>
 
  <script src="javascript/pass-show-hide.js"></script>
  <script src="javascript/login.js"></script>

</body>
</html>
